package CodeMessageType;

public class MESSAGE {


}
