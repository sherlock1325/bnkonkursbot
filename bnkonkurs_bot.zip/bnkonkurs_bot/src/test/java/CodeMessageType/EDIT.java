package CodeMessageType;

public class EDIT {

}
