package Controller;

import org.telegram.telegrambots.meta.api.methods.send.SendMessage;

import java.util.LinkedList;

public class Settings {

}
