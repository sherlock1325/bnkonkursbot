package util;

public class InlineKeyboardButton {

}
